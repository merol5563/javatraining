package day04_Variables;

public class EmployeeInfo {

    public static void main(String[] args) {

        String employeeName = "Maria";
        int age = 24;
        char gender = 'F';
        String company = "Apple Inc";
        String jobTitle ="SDET";
        double yearsofExperince = 2.5;
        int salary =120000;
        boolean isFullTime = true;
        boolean isMarried = false;
        String emploeeId = "A101";
        String SSN ="(123)-45-6789";

        System.out.println("name = " + "name");
        System.out.println("emploeeId = " + emploeeId);
        System.out.println("gender = " + gender);
        System.out.println("age = " + age);
        System.out.println("jobTitle = " + jobTitle);
        System.out.println("company = " + company);
        System.out.println("yearsofExperince = " + yearsofExperince);
        System.out.println("isFullTime = " + isFullTime);
        System.out.println("salary = " + salary);
        System.out.println("isMarried = " + isMarried);
        System.out.println("SSN = " + SSN);







    }

}
/*
6. Create a class employeeNamed EmployeeInfo. declare the following variables:
				1. employeeName (String)
				2. age (int)
				3. gender (char)
				4. company (String)
				5. jobTitle (String)
				6. yearsOfExperience (double)
				7. salary (int)
				8. isFullTime (boolean)
				9. isMarried (boolean)
				10. employeeId (String)
				11. SSN (String)
*/
