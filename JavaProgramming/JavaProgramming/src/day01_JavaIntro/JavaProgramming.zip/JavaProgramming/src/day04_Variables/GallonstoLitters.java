package day04_Variables;

public class GallonstoLitters {

    public static void main(String[] args) {
        int gallons = 1000;

        double litters = gallons * 3.79 ;

        System.out.println("litters = " + litters);



    }

}

