package day04_Variables;
public class Square {

    public static void main(String[] args) {
        //DataType variableName = Data;

        double side = 8.5;

        double area = side * side;
        double perimeter = side * 4;

        System.out.println("side = " + side);
        System.out.println("area = " + area);
        System.out.println("perimeter = " + perimeter);


    }

}




