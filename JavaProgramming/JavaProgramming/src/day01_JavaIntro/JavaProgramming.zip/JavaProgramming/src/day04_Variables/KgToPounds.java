package day04_Variables;

public class KgToPounds {
    public static void main(String[] args) {
    int kg = 75;

    double lb = kg * 2.2;

    //   System.out.println("kg = " + kg);
    System.out.println("lb = " + lb);

}

}

