package day02_HelloWorld;

public class ClassMates {

    public static void main(String[] args) {
        System.out.println("Hamit");
        System.out.println("Halil");
        System.out.println("Hasan");
        System.out.println("Hikmet");
        System.out.println("Veli");
    }

}



