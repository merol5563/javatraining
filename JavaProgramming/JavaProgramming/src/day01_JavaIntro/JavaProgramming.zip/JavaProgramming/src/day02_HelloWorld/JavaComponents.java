package day02_HelloWorld;

public class JavaComponents  {

    public static void main(String[] args) {
        System.out.println("JDK");
        System.out.println("JRE");
        System.out.println("JVM");
    }
}
