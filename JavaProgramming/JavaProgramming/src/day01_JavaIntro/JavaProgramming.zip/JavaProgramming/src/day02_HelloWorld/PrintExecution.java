package day02_HelloWorld;

public class PrintExecution {

    public static void main(String[] args) {

        System.out.println("Duygu");
        System.out.println("Oleksandr");
        System.out.println("Zoia");
        System.out.println();
        System.out.println("Ahmet");
        System.out.println("Yuliya");
        System.out.println("Cassandra");
        System.out.println();
        System.out.println("Cydeo");
    }

}






