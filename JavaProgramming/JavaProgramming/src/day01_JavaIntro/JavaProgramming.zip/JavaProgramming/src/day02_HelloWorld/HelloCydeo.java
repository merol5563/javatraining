package day02_HelloWorld;

public class HelloCydeo {

    public static void main(String[] args) {

        System.out.println("Hello Cydeo");
        System.out.println("Wooden Spoon");
        System.out.println("Hello World");
    }
}



