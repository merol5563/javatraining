package day01_JavaIntro;

public class day01_IntroJava {

    public static void main(String[] args) {

        System.out.println("Hello World");
    }
}
