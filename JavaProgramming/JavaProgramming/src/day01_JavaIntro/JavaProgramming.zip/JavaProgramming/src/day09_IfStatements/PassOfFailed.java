package day09_IfStatements;

public class PassOfFailed {

    public static void main(String[] args) {

        int score = 75;

        if (score >= 60) {
            System.out.println("Congrats,you passed");
        } else {

            System.out.println("Failed");
        }
    }
}