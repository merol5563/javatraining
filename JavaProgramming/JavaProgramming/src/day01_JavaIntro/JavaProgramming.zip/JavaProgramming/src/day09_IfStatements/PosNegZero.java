package day09_IfStatements;

public class PosNegZero {

    public static void main(String[] args) {

        int n = 100;

        if (n > 0) {
            System.out.println("Positive");

        }
        if (n < 0) {
            System.out.println("Negative");
        }

        if (n == 0) {
            System.out.println("Zero");
        }

        System.out.println("-------------------------------------------------------------");

        boolean Positive = n > 0;
        boolean Negative = n > 0;

        if (Positive){
            System.out.println("Positive");
        }else if (Negative) {
            System.out.println("Negative");
        }else {
            System.out.println("Zero");
        }


        System.out.println("------------------");

        if (Positive) {
            System.out.println("Positive");
        }

        if (Negative) {
            System.out.println("Negative");
        }else {
            System.out.println("Zero");

        }
        //if & else statement we can NEVER apply for the task that requires more than two condation



    }
}