package HomeWork;

public class Square {
    public static void main(String[] args) {
        System.out.print("\t\t\t\t* * * * * * *\n");
        System.out.print("\t\t\t\t*\t\t\t*\n");
        System.out.print("\t\t\t\t*\t\t\t*\n");
        System.out.print("\t\t\t\t*\t\t\t*\n");
        System.out.print("\t\t\t\t*\t\t\t*\n");
        System.out.print("\t\t\t\t*\t\t\t*\n");
        System.out.print("\t\t\t\t* * * * * * *\n");

    }
}

