package day03_EscapeSquences;
public class AboutMe {

    public static void main(String[] args) {

        System.out.println("\tMy favorite music is \"Rock\" musics. \n\t\t\t\tMy favorite book is \"Data Structure in Java\"");


    }

}
