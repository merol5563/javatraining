package day03_EscapeSquences;

public class GasReceipt {

    public static void main(String[] args) {

        System.out.println();
        System.out.println("    MCLEAN STORE");
        System.out.println();
        System.out.println("09/20/2021  09:35pm");
        System.out.println();
        System.out.println("Gallons:    11");
        System.out.println("Prise/gallon  $2.089");
        System.out.println();
        System.out.println("Fuel total:   $24.734");

    }
}
