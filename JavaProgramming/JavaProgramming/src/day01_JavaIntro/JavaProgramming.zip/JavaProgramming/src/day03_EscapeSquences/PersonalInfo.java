package day03_EscapeSquences;

public class PersonalInfo {

    public static void main(String[] args) {

        System.out.println("Name: John");
        System.out.println("Gender: Male");
        System.out.println("Date Of Birth:  6/19/1993");
        System.out.println("Address:  Los Angles, CA");
        System.out.println("Phone: (123)-304-2698");
        System.out.println("SSN: (***)-**-**87 ");

    }
}
