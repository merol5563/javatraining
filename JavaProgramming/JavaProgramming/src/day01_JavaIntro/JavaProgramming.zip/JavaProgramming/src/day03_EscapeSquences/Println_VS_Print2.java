package day03_EscapeSquences;

public class Println_VS_Print2 {

    public static void main(String[] args) {

        System.out.println("Knock Knock");
        System.out.println("Who is this?");

        System.out.println("This is Java");

        System.out.println("______________________");

        System.out.print("Knock Knock");
        System.out.print("Who is this?");
        System.out.print("This is Java");

        System.out.println();
        System.out.println("_________________________");

        System.out.println("Hello Everyone,How are you all today?Today we will learn Escape squence,and next week we will learn Veriables");
        System.out.println("_______________________________");

        System.out.print("Hello Everyone,How are you all today?");
        System.out.print("Today we will learn Escape squence,");
        System.out.print("and next week we will learn Veriables");

    }
}
