package day03_EscapeSquences;

public class Triangle {

    public static void main(String[] args) {

        System.out.println("\t\t\t    ^");
        System.out.println("\t\t\t   / \\");
        System.out.println("\t\t\t  /   \\");
        System.out.println("\t\t\t /     \\");
        System.out.println("\t\t\t/       \\");
        System.out.println("\t\t\t---------");


    }

}