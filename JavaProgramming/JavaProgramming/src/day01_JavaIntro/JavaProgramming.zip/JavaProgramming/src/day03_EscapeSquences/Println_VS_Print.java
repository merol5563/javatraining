package day03_EscapeSquences;

public class Println_VS_Print {

    public static void main(String[] args) {

        System.out.println("Hello Cydeo");
        System.out.println("How are all today?");

        System.out.println("________________________");

        System.out.print("Hello Cydeo");
        System.out.println("How are you all today?");

        System.out.println("Java Programming");

        System.out.print("Wooden Spoon");
        System.out.println("I love Java");
    }
}
