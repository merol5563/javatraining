package day03_EscapeSquences;

public class RightTriangle {
    public static void main(String[] args) {

        System.out.println("*");
        System.out.println("* *");
        System.out.println("* * *");
        System.out.println("* * * *");
        System.out.println("* * * * *");
        System.out.println("* * * * * *");
        System.out.println("* * * * * * *");
    }
}
