package day03_EscapeSquences;

public class Err_VS_Out {



        public static void main(String[] args) {

            System.out.println("Hello World");

            System.out.println("----------------------------------");

            System.err.println("Hello World");
 }}
