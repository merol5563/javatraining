package day06_PrimetiveTypeCasting;

public class BirthDay {

    public static void main(String[] args) {
        String name = "Aaron";
        int birthDay = 25;
        String month = "April";
        int birthYear =1995;

        //John  was born on month/day/year.
        System.out.println(name+ " was born on "+ month + "/" +birthDay +"/"+birthYear);

        System.out.println("----------------------------------------------------");

        // My favorite book is "bookName"
        String bookName ="The Rich Dad and The Poor Dad";

        System.out.println("My favorite book is " + "\"" +bookName+"\"");


    }

}
