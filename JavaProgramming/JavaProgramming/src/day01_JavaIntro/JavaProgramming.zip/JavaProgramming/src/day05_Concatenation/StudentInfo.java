package day05_Concatenation;

public class StudentInfo {

    public static void main(String[] args) {
        String student_name = "Tamara";
        int age = 45;
        char gender = 'F';
        String schoolName ="Cydeo";
        String phoneNumber ="(123)-456-7891";
        boolean isFullTime = true;
        double GPA =3.5;

        System.out.println("student_name = " + student_name);
        System.out.println("age = " + age);
        System.out.println("gender = " + gender);
        System.out.println("schoolName = " + schoolName);
        System.out.println("phoneNumber = " + phoneNumber);
        System.out.println("GPA = " + GPA);




    }
}
