package day05_Concatenation;

public class Introduction {

    public static void main(String[] args) {
        String name = "Jimmy";
        int age = 39;

        System.out.println("Hello Everyone,My name is " + name +", and I am "+ age +" years old.");

    }
}
